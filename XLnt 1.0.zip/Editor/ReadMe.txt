XLnt ii user interface editor v1.3.2 (for XLnt GUI v1.41)

Coded by Kefir

What's new:

version 1.3.2
- Updated to use with XLnt v1.41

version 1.3.1
- First stable release, I think :)
- Some small bug fixed

version 1.3b
- Icon selection for the menu items added
- Some bug fixed

version 1.2.2b
- Icon rename bug fixed
- Frame size saving\loading bug fixed
- Some small bugs fixed

version 1.2.1b
- Some major bugs fixed with deleting attached gadgets, and others...

version 1.2b
- Full support of XLnt v1.3, I hope 8)
- Set icon bug fixed: if gadget already have the icon and you press "Set icon" and in icon sel. window press "Cancel", gadget not lose its icon
- Panel resize bug fixed
- Now you can completelly resize window tab area
- Many 'attachment' bugs fixed

version 1.1b
- Adapt code to XLnt v1.3
- Some small bug fixed

version 1.0.4b
- Icon editor bug fixed: now you can change and delete the icons created by you (not standart GUI icons)
- Attachment bug fixed: then you attach already attached gadget - now it's completely work
- Reposition panel bug fixed
- UI Editor project file extension changed to '.xlntw' because old ext '.xlw' used by Microsoft Excell. You can load older .xlw files but now you can only save with extension '.xlntw'

version 1.0.3b
- Initial public version


p.s. Current version of the editor is not stable therefore save progress more often 8)

IMPORTANT:

If you receive an error in GUI_FRAME function then replace this function in 'XGad.bb' by this:

Function GUI_FRAME(XL_WIN,xl_X,xl_Y,XL_W,XL_H,XL_TXT$="",XL_TYP=0,XL_TAB=0,XL_ACT=True,XL_HLP$="", BringToBack=True)
	RET.GAD=New GAD
	RET\WIN=Object.WIN(XL_WIN):WIN.WIN=RET\WIN
	RET\TAB=XL_TAB
	RET\STATUS=1
	RET\ACTIVE=XL_ACT
	RET\ID=GUI_ID():RET\OBJ=Handle(RET)
	RET\TYP=gad_FRAME
	RET\X=xl_X:RET\Y=xl_Y
	RET\W=XL_W:RET\H=XL_H
	RET\PAD[0]=XL_TYP
	RET\CAP$=XL_TXT$
	If RET\CAP$<>""
		RET\H=RET\H-6
	EndIf
	For XL_T=0 To 3
		RET\COL[XL_T]=WIN\WCOL[XL_T]
	Next
	If BringToBack Insert RET Before First GAD
	RET\PANEL=WIN\PANEL
	RET\TW=RET\W:RET\TH=RET\H
	GUI_SETGADTAB(RET\OBJ)
	RET\HELP$=XL_HLP$
	Return RET\OBJ
End Function