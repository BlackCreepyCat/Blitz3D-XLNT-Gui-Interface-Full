XLnt ii

Version: v1.41

Bug Fix version of v1.4

Thank you for downloading this version of XLnt ii

Please read the XLnt User Guide for more info - i'm not over keen on producing example code as you can see, but I think XLnt is easy enough to get to grips with and you should be able to produce some great UIs in no time.


Non-Registered Users:
This archive contains all of the current functions/features [and bugs] of XLnt ii GUI. However, users who have not registered are limited in their use of the XLnt ii GUI library. They may not release ANY software created using, or containing, XLnt ii code. This restriction applies to all programs and source code - FreeWare, Public Domain, ShareWare, or Commercial Software.
To register as an XLnt ii User please visit www.xlnt.co.uk


Registered Users:
This archive contains XPlugin.bb so make sure you don't overwrite any of your own code!

Have fun!

cheers 

yappy

EMail : stew@xlnt.co.uk

Web : www.xlnt.co.uk

Forum : http://playerfactory.proboards25.com/index.cgi - open to all!!!




